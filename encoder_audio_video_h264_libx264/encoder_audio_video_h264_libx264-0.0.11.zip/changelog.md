**<span style="color:#56adda">0.0.11</span>**
- Ensure audio stream is transcoded to aac

**<span style="color:#56adda">0.0.10</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">0.0.9</span>**
- Enabled support for v2 plugin executor

**<span style="color:#56adda">0.0.8</span>**
- Ensure no static vars are used with when stream mapping

**<span style="color:#56adda">0.0.7</span>**
- Add list of image video streams to ignore

**<span style="color:#56adda">0.0.6</span>**
- Tidy up description

**<span style="color:#56adda">0.0.5</span>**
- Fix bug in setting extension when manually specifying the container

**<span style="color:#56adda">0.0.4</span>**
- Limit plugin to only process files with a "video" mimetype

**<span style="color:#56adda">0.0.3</span>**
- Add HW accelerated decoding option

**<span style="color:#56adda">0.0.2</span>**
- Add ability to set the output container
- Add icon

**<span style="color:#56adda">0.0.1</span>**
- initial version
